#include <stdio.h>
#include "math_utils.h"

int main() {
    int num = 5;
    printf("The square of %d is %d\n", num, square(num));
    return 0;
}