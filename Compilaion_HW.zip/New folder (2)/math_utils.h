#ifndef MATH_UTILS_H
#define MATH_UTILS_H

int square(int x);

#endif