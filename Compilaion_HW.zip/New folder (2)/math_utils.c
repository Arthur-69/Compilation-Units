#include "math_utils.h"

int square(int x) {
    return x * x;
}